package controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import data.AuthenticationDAO;
import data.User;

@Controller
public class RegistrationController {
	
	@Autowired
	private AuthenticationDAO authDao;
	
	@RequestMapping(path="register.do", method=RequestMethod.GET)
	public ModelAndView register() {
		ModelAndView mv = new ModelAndView();
		// TODO: Create a user command object for use with the registration form 
		// and return the 'register.jsp'
		return mv;
	}
	
	// TODO: Add the @Valid annotation to the User object
	// TODO: Inject the Errors object
	@RequestMapping(path="register.do", method=RequestMethod.POST)
	public String create(User user) {
		// TODO: 1. If there are any errors, return the 'register.jsp'
		// TODO: 2. Check the email's uniqueness with the DAO's emailIsUnique
		//          if the email already exists, add an additional error (use 
		//          errors.rejectValue()...).
		return "profile.jsp";
	}
}
