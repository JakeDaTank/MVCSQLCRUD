package data;

public interface AuthenticationDAO {
	public User create(User user);
	public boolean emailIsUnique(String email);
	public User validEmail(String email);
	public boolean validPassword(User u);

}
