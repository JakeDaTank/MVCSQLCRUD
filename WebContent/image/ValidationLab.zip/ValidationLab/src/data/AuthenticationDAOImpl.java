package data;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

@Repository
public class AuthenticationDAOImpl implements AuthenticationDAO {
	Map<String, User> users = new HashMap<>();
	
	public AuthenticationDAOImpl () {
		this.users.put("admin@admin.com", 
				new User("admin@admin.com", "admin", "admin", "password", 22));
	}

	@Override
	public User create(User user) {
		if (emailIsUnique(user.getEmail())) {
			users.put(user.getEmail(), user);
			return user;
		}
		return null;
	}

	@Override
	public boolean emailIsUnique(String email) {
		// TODO: Check to see if the provided email exists as a key in the users HashMap
		return false;
	}

	@Override
	public User validEmail(String email) {
		if (users.containsKey(email)) {
			return users.get(email);
		}
		return null;
	}

	@Override
	public boolean validPassword(User u) {
		if (validEmail(u.getEmail()) == null) {
			return false;
		}
		if (users.get(u.getEmail())
				.getPassword()
				.equals(u.getPassword())){
			return true;
		}
		return false;
	}
}
