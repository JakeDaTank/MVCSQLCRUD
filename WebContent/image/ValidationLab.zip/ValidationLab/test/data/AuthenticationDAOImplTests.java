package data;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AuthenticationDAOImplTests {
	private AuthenticationDAOImpl dao;
	
	@Before
	public void setUp(){
		dao = new AuthenticationDAOImpl();
		//Users in default object are...
			//email: admin@admin.com"
			//firstname: "admin"
			//lastname: "admin"
			//password: "password"
			//age: 22
	}
	@After
	public void tearDown(){
		dao = null;
	}
	
	@Test
	public void testCreateWithUniqueEmailReturnsUserObjectAndAddsToDAO(){
		User user = new User("admin2@admin.com", "firstName", "ln", "password", 15);
		assertNotNull(dao.create(user));
		
		User u2 = dao.validEmail("admin2@admin.com");
		assertEquals(user.getEmail(), u2.getEmail());
		assertEquals(user.getAge(), u2.getAge());
	}
	
	@Test
	public void testCreateWithNonUniqueEmailReturnsNull(){
		User user = new User("admin@admin.com", "firstName", "ln", "password", 15);
		assertNull(dao.create(user));
		
		User u2 = dao.validEmail("admin@admin.com");
		assertEquals("admin", u2.getFirstName());
	}
	
	@Test
	public void testValidEmailReturnsUser(){
		User u2 = dao.validEmail("admin@admin.com");
		assertEquals("admin", u2.getFirstName());
	}
	
	@Test
	public void testValidEmailWithInvalidEmailReturnsNull(){
		assertNull(dao.validEmail("XXX"));
	}
	
	@Test
	public void testValidPasswordWithUserNotInDAOreturnsFalse(){
		User user = new User("admin2@admin.com", "firstName", "ln", "password", 15);
		assertFalse(dao.validPassword(user));
	}
	
	@Test
	public void testValidPasswordWithUserInDAOwithWrongPasswordReturnsFalse(){
		User user = new User("admin@admin.com", "firstName", "ln", "passwordBad", 15);
		assertFalse(dao.validPassword(user));
	}
	
	@Test
	public void testValidPasswordWithUserWithValidEmailCorrectPasswordReturnsTrue(){
		User user = new User("admin@admin.com", "firstName", "ln", "password", 15);
		assertTrue(dao.validPassword(user));
	}
	
	@Test
	public void testEmailIsUniqueWithEmailInUseReturnsFalse(){
		assertFalse(dao.emailIsUnique("admin@admin.com"));
	}
	
	@Test
	public void testEmailIsUniqueWithEmailNotInUseReturnsTrue(){
		assertTrue(dao.emailIsUnique("XXX@admin.com"));
		
	}
}
