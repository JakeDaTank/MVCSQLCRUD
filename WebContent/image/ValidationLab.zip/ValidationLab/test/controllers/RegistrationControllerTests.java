package controllers;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import data.AuthenticationDAOImpl;
import data.User;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class RegistrationControllerTests {
	@Autowired
	WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	@Autowired
	AuthenticationDAOImpl dao;
	
	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@After
	public void tearDown() throws Exception {
		dao = null;
		mockMvc = null;
		wac = null;
	}
	
	@Test
	public void testGETRegisterDoReturnsRegisterViewWithUserInModel(){
		try {
			MvcResult result = mockMvc.perform(get("/register.do")).andExpect(status().isOk()).andReturn();
			ModelAndView modelAndView = result.getModelAndView();
			assertThat(modelAndView,
						hasProperty("viewName", is("register.jsp"))
					);
			User u = (User) modelAndView.getModelMap().get("user");
			assertThat(u, 
				allOf(
				hasProperty("email", nullValue()),			
				hasProperty("password", nullValue()),			
				hasProperty("firstName", nullValue()),			
				hasProperty("lastName", nullValue()),			
				hasProperty("age", nullValue())				
				));
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTRegisterDoReturnsProfileViewWithUserInModelAndStoredInDAO(){
		try {
			//Perform a post with all user fields
			//Expect status isOk and return MvcResult
			MvcResult result = mockMvc.perform(
					post("/register.do")
					.param("firstName", "Roger")
					.param("lastName", "Dodger")
					.param("password", "pwdsix")
					.param("age", "25")
					.param("email", "email@localhost.com")
					)
					.andExpect(status().isOk())
					//make sure there are no errors
					.andExpect(model().errorCount(0))
					.andReturn();
			
			//Get the modelAndView and check viewName
			ModelAndView modelAndView = result.getModelAndView();
			
			assertThat(modelAndView,
						hasProperty("viewName", is("profile.jsp"))
					);
			
			//Get User from ModelAndView's modelMap and check fields
			User u = (User) modelAndView.getModelMap().get("user");
			assertThat(u, 
				allOf(
						hasProperty("firstName", is("Roger")),
						hasProperty("lastName", is("Dodger")),
						hasProperty("password", is("pwdsix")),
						hasProperty("age", is(25)),
						hasProperty("email", is("email@localhost.com"))			
				));
			
			//Check DAO for value
			User daoUser = dao.validEmail("email@localhost.com");
			assertThat(daoUser, 
					allOf(
							hasProperty("firstName", is("Roger")),
							hasProperty("lastName", is("Dodger")),
							hasProperty("password", is("pwdsix")),
							hasProperty("age", is(25)),
							hasProperty("email", is("email@localhost.com"))			
					));
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTRegisterDoReturnsRegisterViewWithErrorsAndUserInModel_ForPasswordLessThanSixChars(){
		try {
			//Perform a post with all user fields
			//Expect status isOk and return MvcResult, checking model for errors
			MvcResult result = mockMvc.perform(
					post("/register.do")
					.param("firstName", "Roger")
					.param("lastName", "Dodger")
					.param("password", "pwd")
					.param("age", "25")
					.param("email", "email@localhost.com")
					)
					.andExpect(status().isOk())
					//make sure there are errors
					.andExpect(model().errorCount(1))
					.andExpect(model().attributeHasFieldErrorCode("user", "password", is("Size")))
					.andReturn();
			
			//Get the modelAndView and check viewName
			ModelAndView modelAndView = result.getModelAndView();
			
			assertThat(modelAndView,
						hasProperty("viewName", is("register.jsp"))
					);
			
			//Get User from ModelAndView's modelMap and check fields are still there
			User u = (User) modelAndView.getModelMap().get("user");
			assertThat(u, 
				allOf(
						hasProperty("firstName", is("Roger")),
						hasProperty("lastName", is("Dodger")),
						hasProperty("password", is("pwd")),
						hasProperty("age", is(25)),
						hasProperty("email", is("email@localhost.com"))			
				));
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTRegisterDoReturnsRegisterViewWithErrorsAndUserInModel_ForNonUniqueEmail(){
		try {
			//Expect status isOk and return MvcResult, checking model for errors
			MvcResult result = mockMvc.perform(
					post("/register.do")
					.param("firstName", "Roger")
					.param("lastName", "Dodger")
					.param("password", "password")
					.param("age", "25")
					.param("email", "admin@admin.com")
					)
					.andExpect(status().isOk())
					.andExpect(model().errorCount(1))
					.andExpect(model().attributeHasFieldErrorCode("user", "email", is("admin@admin.com")))
					.andReturn();
			
			//Get the modelAndView and check viewName
			ModelAndView modelAndView = result.getModelAndView();
			
			//Check errors another way
			BindingResult r = (BindingResult) modelAndView.getModelMap().get("org.springframework.validation.BindingResult.user");
			
			ObjectError e = r.getAllErrors().get(0);
			
			assertEquals(e.getObjectName(), "user");
			assertEquals(e.getCode(), "admin@admin.com");
			assertThat(modelAndView,
						hasProperty("viewName", is("register.jsp"))
					);
			
			//Get User from ModelAndView's modelMap and check fields are still there
			User u = (User) modelAndView.getModelMap().get("user");
			assertThat(u, 
				allOf(
						hasProperty("firstName", is("Roger")),
						hasProperty("lastName", is("Dodger")),
						hasProperty("password", is("password")),
						hasProperty("age", is(25)),
						hasProperty("email", is("admin@admin.com"))			
				));
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTRegisterDoReturnsRegisterViewWithErrorsAndUserInModel_ForAgeLessThan16(){
		try {
			MvcResult result = mockMvc.perform(
				post("/register.do")
				.param("firstName", "Roger")
				.param("lastName", "Dodger")
				.param("password", "password")
				.param("age", "15")
				.param("email", "email@localhost.com")
				)
				.andExpect(status().isOk())
				//Check errors the preferred way
				.andExpect(model().errorCount(1))
				.andExpect(model().attributeHasFieldErrorCode("user", "age", is("Min")))
				.andReturn();
			
			//Get the modelAndView and check viewName
			ModelAndView modelAndView = result.getModelAndView();
			
			assertThat(modelAndView,
						hasProperty("viewName", is("register.jsp"))
					);
			
			//Get User from ModelAndView's modelMap and check fields are still there
			User u = (User) modelAndView.getModelMap().get("user");
			assertThat(u, 
				allOf(
						hasProperty("firstName", is("Roger")),
						hasProperty("lastName", is("Dodger")),
						hasProperty("password", is("password")),
						hasProperty("age", is(15)),
						hasProperty("email", is("email@localhost.com"))			
				));
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTRegisterDoReturnsRegisterViewWithErrorsAndUserInModel_ForFirstNameLessThan3OrGreaterThan35(){
		try {
			//Expect status isOk and return MvcResult, checking model for errors
			MvcResult result = mockMvc.perform(
					post("/register.do")
					.param("firstName", "Ro")
					.param("lastName", "Dodger")
					.param("password", "password")
					.param("age", "25")
					.param("email", "email@localhost.com")
					)
					.andExpect(status().isOk())
					.andReturn();
			
			//Get the modelAndView and check viewName
			ModelAndView modelAndView = result.getModelAndView();
			
			//Check errors another way
			BindingResult r = (BindingResult) modelAndView.getModelMap().get("org.springframework.validation.BindingResult.user");
			
			ObjectError e = r.getAllErrors().get(0);
			
			assertEquals(e.getObjectName(), "user");
			assertEquals(e.getCode(), "Size");
			//There are several versions of a code. Check one of them
			assertTrue(Arrays.asList(e.getCodes()).contains("Size.user.firstName"));
			
			assertThat(modelAndView,
						hasProperty("viewName", is("register.jsp"))
					);
			
			//Second request
			String name = "a";
			for(int i=0; i<35; i++){
				name += "a";
			}
			result = mockMvc.perform(
					post("/register.do")
					.param("firstName", name)
					.param("lastName", "Dodger")
					.param("password", "password")
					.param("age", "25")
					.param("email", "email@localhost.com")
					)
					.andExpect(status().isOk())
					.andReturn();
			
			//Get the modelAndView and check viewName
			modelAndView = result.getModelAndView();
			
			//Check errors the clunky way
			r = (BindingResult) modelAndView.getModelMap().get("org.springframework.validation.BindingResult.user");
			e = r.getAllErrors().get(0);
			
			assertEquals(e.getObjectName(), "user");
			assertEquals(e.getCode(), "Size");
			//There are several versions of a code.
			assertTrue(Arrays.asList(e.getCodes()).contains("Size.user.firstName"));
			assertTrue(Arrays.asList(e.getCodes()).contains("Size.firstName"));
			
			assertThat(modelAndView,
						hasProperty("viewName", is("register.jsp"))
					);
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTRegisterDoReturnsRegisterViewWithErrorsAndUserInModel_ForLastNameLessThan30OrNameGreaterThan35(){
		//TODO - implement
		fail("implement");
	}
}
