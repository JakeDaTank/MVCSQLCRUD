package controllers;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import data.User;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class LoginControllerTests {
	@Autowired
	WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	@Autowired
	RegistrationController controller;
	
	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@After
	public void tearDown() throws Exception {
		controller = null;
		mockMvc = null;
		wac = null;
	}
	
	@Test
	public void testGETLoginReturnsLoginJSPWithDefaultUserInModel(){
		
	}
	
	@Test
	public void testPOSTLoginEmailInvalidUserReturnsLoginJSPWithEmailError(){
		try {
			//Expect status isOk and return MvcResult, checking model for errors
			MvcResult result = mockMvc.perform(
					post("/login.do")
					.param("password", "password")
					.param("email", "admin@adminXXX.com")
					)
					.andExpect(status().isOk())
					//make sure there is an error
					.andExpect(model().attributeHasFieldErrorCode("user", "email", is("login.email")))
					.andReturn();
			
			//Get the modelAndView and check viewName
			ModelAndView modelAndView = result.getModelAndView();
			
			assertThat(modelAndView,
						hasProperty("viewName", is("login.jsp"))
					);
			
			//Get User from ModelAndView's modelMap and check fields are still there
			User u = (User) modelAndView.getModelMap().get("user");
			assertThat(u, 
				allOf(
						hasProperty("firstName", nullValue()),
						hasProperty("lastName", nullValue()),
						hasProperty("password", is("password")),
						hasProperty("age", nullValue()),
						hasProperty("email", is("admin@adminXXX.com"))			
				));
		}
		catch(Exception e){
			fail(e.toString());
		}
	}
	
	@Test
	public void testPOSTLoginEmailValidUserInvalidPasswordReturnsLoginJSPWithPasswordError(){
		//TODO - implement
		fail("implement");
	}
	
	@Test
	public void testPOSTLoginValidUserReturnsProfileJSPWithUserInModel(){
		//TODO - implement
		fail("implement");
	}
}
